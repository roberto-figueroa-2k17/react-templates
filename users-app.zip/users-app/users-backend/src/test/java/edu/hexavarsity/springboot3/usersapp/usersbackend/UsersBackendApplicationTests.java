package edu.hexavarsity.springboot3.usersapp.usersbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
