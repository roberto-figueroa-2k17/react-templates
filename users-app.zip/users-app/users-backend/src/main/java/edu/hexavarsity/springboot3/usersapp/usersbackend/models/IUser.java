package edu.hexavarsity.springboot3.usersapp.usersbackend.models;

public interface IUser {

    boolean isAdmin();
}
