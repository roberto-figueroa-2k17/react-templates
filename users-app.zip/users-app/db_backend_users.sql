DROP DATABASE IF EXISTS `db_backend_users`;

-- Crear la base de datos con conjunto de caracteres UTF-8
CREATE DATABASE IF NOT EXISTS `db_backend_users` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usar la base de datos recién creada
USE `db_backend_users`;

-- Crear la tabla 'users'
CREATE TABLE `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50),
  `lastname` VARCHAR(50),
  `email` VARCHAR(100),
  `username` VARCHAR(50),
  `password` VARCHAR(100),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crear la tabla 'roles'
CREATE TABLE `roles` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crear la tabla intermedia 'users_roles' para la relación muchos a muchos
CREATE TABLE `users_roles` (
  `user_id` INT NOT NULL,
  `role_id` INT NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Agregar índice a la columna 'role_id' de la tabla 'users_roles'
ALTER TABLE `users_roles`
ADD INDEX `fk_roles_idx` (`role_id` ASC);

-- Agregar claves foráneas para establecer las relaciones
ALTER TABLE `users_roles`
ADD CONSTRAINT `fk_users`
  FOREIGN KEY (`user_id`)
  REFERENCES `users` (`id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT,
ADD CONSTRAINT `fk_roles`
  FOREIGN KEY (`role_id`)
  REFERENCES `roles` (`id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;

-- Insertar registros de ejemplo en la tabla 'roles'
INSERT INTO `roles` (`name`) VALUES 
('ROLE_ADMIN'),
('ROLE_USER'),
('ROLE_MANAGER');

-- Insertar registros de ejemplo en la tabla 'users'
INSERT INTO `users` (`name`, `lastname`, `email`, `username`, `password`) VALUES 
('Administrador', 'del Sistema Spring Boot 3 Demo', 'admin@hexavarsity.spring.edu', 'admin', '$2a$12$bWrCW2b4O4Fj3UUErUErRu.cLgLzFSkGtZeZgShXaCsh2cfLHhzEq'), -- admin
('John', 'Doe', 'john.doe@example.com', 'johndoe', '$2a$12$bIfNGwDwAa0BiR5ywzBRNugzhQ7QDnJCtObIUsBSm5FvzKBTiyo0e'), -- password123
('Jane', 'Smith', 'jane.smith@hexavarsity.spring.edu', 'janesmith', '$2a$12$pkcq2ELe8TX3IS.mJddeXeriP8N/YcLdFvtsulZW.cSngiPHN9Y4q'), -- mypassword
('Michael', 'Johnson', 'michael.johnson@hexavarsity.spring.edu', 'mjohnson', '$2a$12$c10NfXsK.6fVaSQ8HYdlfeVuFEnX6X8phaC5H1NEO270XvomSkf4m'), -- securepass
('Emily', 'Davis', 'emily.davis@hexavarsity.spring.edu', 'edavis', '$2a$12$x3S.EXuY4fGK9ecNY0XZT.LCJJFxHuUISwnzLKz382aw1wYDUrb8C'), -- emilypass
('David', 'Brown', 'david.brown@hexavarsity.spring.edu', 'dbrown', '$2a$12$EDxmEhu8cyNfBr3p0AbDxe8X6MkxRNbjtDx282sy6P.CTbijSsmTm'), -- david123
('Sarah', 'Wilson', 'sarah.wilson@hexavarsity.spring.edu', 'swilson', '$2a$12$Dt5zKtLAbN/Jkl4rzjYy2Ooep45oMFKJxOexiE.g49fQCS.HGNJdu'), -- sarahpass
('Robert', 'Taylor', 'robert.taylor@hexavarsity.spring.edu', 'rtaylor', '$2a$12$687nmR2kRRPPyf4nyY6qketZQz8KZMdExmuF6ykU9ULqbXdxaRQsW'), -- robertpass
('Linda', 'Moore', 'linda.moore@example.com', 'lmoore', '$2a$12$CcZkKoUdT8rmqGv0MiJV8eTHasW1o6yXyybaq8g0jtJXHcQlHnogm'), -- lindapass
('James', 'Anderson', 'james.anderson@example.com', 'janderson', '$2a$12$7dPvfoCWiWDaSrpU3aK6kOlAW3JHL2wRojBN0msCMDn/jj/HiNiWy'); -- jamespass

-- Insertar registros de ejemplo en la tabla 'users_roles'
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES 
(1, 1),
(2, 2),
(3, 2),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 2);
