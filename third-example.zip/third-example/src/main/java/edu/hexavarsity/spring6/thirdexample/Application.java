package edu.hexavarsity.spring6.thirdexample;

import edu.hexavarsity.spring6.thirdexample.config.AppConfig;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import java.io.File;

public class Application {

    public static void main(String[] args) throws Exception {
        // Crear un contexto de aplicación de Spring
        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
        context.register(AppConfig.class);

        // Configurar Tomcat embebido
        Tomcat tomcat = new Tomcat();
        tomcat.setPort(9090); // Configura el puerto en el que se ejecutará Tomcat

        // Crear y configurar el contexto de la aplicación
        File base = new File(System.getProperty("java.io.tmpdir"));
        org.apache.catalina.Context ctx = tomcat.addContext("", base.getAbsolutePath());

        // Asociar el ServletContext del servidor Tomcat al contexto de la aplicación de Spring
        context.setServletContext(ctx.getServletContext());

        // Registrar DispatcherServlet
        DispatcherServlet dispatcherServlet = new DispatcherServlet(context);
        Tomcat.addServlet(ctx, "dispatcherServlet", dispatcherServlet).setLoadOnStartup(1);

        // Mapeo corregido del servlet para manejar todas las solicitudes
        ctx.addServletMappingDecoded("/", "dispatcherServlet");

        // Inicializar el contexto de la aplicación de Spring
        context.refresh();

        // Imprimir los beans registrados para diagnóstico
        String[] beanNames = context.getBeanDefinitionNames();
        System.out.println("Registered Beans:");
        for (String beanName : beanNames) {
            System.out.println(beanName);
        }

        // Añadir logs de depuración antes de iniciar el servidor
        Connector connector = tomcat.getConnector();  // Obtener el conector de Tomcat
        System.out.println("Starting Tomcat on port: " + connector.getPort());
        System.out.println("Application context registered: " + ctx.getPath());
        System.out.println("Awaiting requests...");

        // Iniciar el servidor Tomcat
        tomcat.start();
        tomcat.getServer().await();
    }
}
