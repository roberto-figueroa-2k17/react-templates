package edu.hexavarsity.spring6.restexample.controller;

import edu.hexavarsity.spring6.restexample.model.Course;
import edu.hexavarsity.spring6.restexample.service.CrudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CourseController {
    @Autowired
    private CrudService crudService;

    @GetMapping("/api/test")
    public String testEndpoint() {
        return "The endpoint is working!";
    }

    @GetMapping("/api/courses")
    public List<Course> getAllCourses() {
        return crudService.findAll();
    }

    @GetMapping("/api/courses/{courseId}")
    public Course getCourseById(@PathVariable int courseId) {
        return crudService.findById(courseId).orElse(null);
    }

    @PostMapping("/api/courses")
    public void createCourse(@RequestBody Course course) {
        crudService.addCourse(course);
    }

    @PutMapping("/api/courses/{courseId}")
    public void updateCourse(@PathVariable int courseId, @RequestBody Course updatedCourse) {
        crudService.updateCourse(courseId, updatedCourse);
    }

    @DeleteMapping("/api/courses/{courseId}")
    public void deleteCourse(@PathVariable int courseId) {
        crudService.deleteCourse(courseId);
    }
}