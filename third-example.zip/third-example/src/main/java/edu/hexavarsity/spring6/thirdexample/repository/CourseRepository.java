package edu.hexavarsity.spring6.thirdexample.repository;

import edu.hexavarsity.spring6.thirdexample.model.Course;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class CourseRepository {
    private List<Course> courses = new ArrayList<>();

    public CourseRepository() {
        courses.add(new Course(1, "Spring 6", "Introduction to Spring Framework 6"));
        courses.add(new Course(2, "Spring Boot 3", "Introduction to Spring Boot 3"));
        courses.add(new Course(3, "Microservices", "Introduction to Microservices"));
    }

    public List<Course> findAll() {
        return new ArrayList<>(courses);
    }

    public Optional<Course> findById(int courseId) {
        return courses.stream().filter(course -> course.getCourseId() == courseId).findFirst();
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void updateCourse(Course course) {
        courses.replaceAll(existingCourse -> 
            existingCourse.getCourseId() == course.getCourseId() ? course : existingCourse);
    }

    public void deleteCourse(int courseId) {
        courses.removeIf(course -> course.getCourseId() == courseId);
    }
}
