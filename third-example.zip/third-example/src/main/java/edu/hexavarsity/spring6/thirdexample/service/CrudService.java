package edu.hexavarsity.spring6.thirdexample.service;

import edu.hexavarsity.spring6.thirdexample.model.Course;
import edu.hexavarsity.spring6.thirdexample.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CrudService {

    private CourseRepository courseRepository;

    @Autowired
    public CrudService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public List<Course> findAll() {
        return courseRepository.findAll();
    }

    public Optional<Course> findById(int courseId) {
        return courseRepository.findById(courseId);
    }

    public void addCourse(Course course) {
        courseRepository.addCourse(course);
    }

    public void updateCourse(int courseId, Course updatedCourse) {
        courseRepository.findById(courseId).ifPresent(course -> {
            course.setTitle(updatedCourse.getTitle());
            course.setDescription(updatedCourse.getDescription());
            courseRepository.updateCourse(course);
        });
    }

    public void deleteCourse(int courseId) {
        courseRepository.deleteCourse(courseId);
    }
}
