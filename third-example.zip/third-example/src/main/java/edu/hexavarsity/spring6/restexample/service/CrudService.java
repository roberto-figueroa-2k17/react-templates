package edu.hexavarsity.spring6.restexample.service;

import edu.hexavarsity.spring6.restexample.model.Course;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CrudService {
    private List<Course> courses = new ArrayList<>();

    public List<Course> findAll() {
        return courses;
    }

    public Optional<Course> findById(int courseId) {
        return courses.stream().filter(course -> course.getCourseId() == courseId).findFirst();
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void updateCourse(int courseId, Course updatedCourse) {
        findById(courseId).ifPresent(course -> {
            course.setTitle(updatedCourse.getTitle());
        });
    }

    public void deleteCourse(int courseId) {
        courses.removeIf(course -> course.getCourseId() == courseId);
    }
}
