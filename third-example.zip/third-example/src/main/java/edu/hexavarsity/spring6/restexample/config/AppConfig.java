package edu.hexavarsity.spring6.restexample.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "edu.hexavarsity.spring6.restexample")
public class AppConfig {
}