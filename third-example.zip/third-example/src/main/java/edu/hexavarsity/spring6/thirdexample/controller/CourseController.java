package edu.hexavarsity.spring6.thirdexample.controller;

import edu.hexavarsity.spring6.thirdexample.model.Course;
import edu.hexavarsity.spring6.thirdexample.service.CrudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {
    @Autowired
    private CrudService crudService;

    @GetMapping("/test")
    public String testEndpoint() {
        return "The endpoint is working!";
    }

    @GetMapping
    public List<Course> getAllCourses() {
        return crudService.findAll();
    }

    @GetMapping("/{courseId}")
    public Course getCourseById(@PathVariable int courseId) {
        return crudService.findById(courseId).orElse(null);
    }

    @PostMapping
    public void createCourse(@RequestBody Course course) {
        crudService.addCourse(course);
    }

    @PutMapping("/{courseId}")
    public void updateCourse(@PathVariable int courseId, @RequestBody Course updatedCourse) {
        crudService.updateCourse(courseId, updatedCourse);
    }

    @DeleteMapping("/{courseId}")
    public void deleteCourse(@PathVariable int courseId) {
        crudService.deleteCourse(courseId);
    }
}