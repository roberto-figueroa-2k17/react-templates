import axios from 'axios';
import config from '../config/config';

const addScenarioData = (scenarioId, tenantOrigId, viewName) => {
    return axios.post(config.serviceUrl + '/addScenarioData', {scenarioId, tenantOrigId, viewName});
}

const getScenarioData = () => {
    return axios.get(config.serviceUrl + '/getScenarioData');
}

const deleteScenarioData = (scenarioId, tenantOrigId, viewName) => {
    return axios.post(config.serviceUrl + '/deleteScenarioData', {scenarioId, tenantOrigId, viewName});
}

export const scenarioApi = {
    addScenarioData,
    getScenarioData,
    deleteScenarioData
};