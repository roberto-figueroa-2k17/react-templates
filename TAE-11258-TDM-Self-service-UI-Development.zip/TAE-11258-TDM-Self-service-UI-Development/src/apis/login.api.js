import axios from 'axios';
import config from '../config/config';

const login = (username, password) => {
    return axios.post(config.serviceUrl + '/login', {username, password});
}

export const loginApi = {
    login
};