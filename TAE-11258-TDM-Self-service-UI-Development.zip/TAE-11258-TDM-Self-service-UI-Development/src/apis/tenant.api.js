import axios from 'axios';
import config from '../config/config';

const addTenantData = (tenantName, tenantId, brand) => {
    return axios.post(config.serviceUrl + '/addTenantData', {tenantName, tenantId, brand});
}

const getTenantData = () => {
    return axios.get(config.serviceUrl + '/getTenantData');
}

const deleteTenantData = (tenantName, tenantId, brand) => {
    return axios.post(config.serviceUrl + '/deleteTenantData', {tenantName, tenantId, brand});
}

export const tenantApi = {
    getTenantData,
    addTenantData,
    deleteTenantData
};