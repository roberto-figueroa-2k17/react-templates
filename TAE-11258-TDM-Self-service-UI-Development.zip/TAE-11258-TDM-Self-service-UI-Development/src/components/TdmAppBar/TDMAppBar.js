import React from "react";
import loginLogo from './../../assets/images/logo.svg';
import userLogo from './../../assets/images/user-logo.PNG';
import './TDMAppBar.css';

const TDMAppBar = () => {

    return (
        <>
            <div>
            <div className="left-cont">
                <img src={loginLogo} width="200" height="50" alt="login page mazda logo" aria-label="login page mazda logo" />
            </div>
            <div className="middle-cont">
                <h2>Test Data Service</h2>
            </div>
            <div className="right-cont">
                <img src={userLogo} width="50" height="50" alt="user logo" aria-label="user logo" />
            </div>
            </div>
        </>
    )
}

export default TDMAppBar;