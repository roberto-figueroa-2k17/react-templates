import logo from './logo.svg';
import './App.css';
import { Router, Routes, Route, Switch } from 'react-router-dom';
import Login  from './Pages/Login/Login';
import Landing  from './Pages/Landing/Landing';
import TenantContainer from './Pages/Tenant/Tenant';

function App_bkp() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={Login} />
        <Route exact path="/landing" component={Landing} />
        <Route exact path="/tenant" component={TenantContainer} />
      </Switch>
    </Router>
  );
}

export default App_bkp;
