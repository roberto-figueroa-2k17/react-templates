import React, { useState } from "react";
import MaterialReactTable from 'material-react-table';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Box from '@mui/material/Box';
import DialogTitle from '@mui/material/DialogTitle';
import { Button, MenuItem } from '@mui/material';
import { EditOutlined, DeleteOutlined } from "@mui/icons-material";
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import './TenantTable.css';
import DataServiceTable from "../../components/DataServiceTable/DataServiceTable";


const TenantTable = props => {
    const { tableData, columns, handleDeleteRow, handleAddRow } = props;
    const [open, setOpen] = useState(false);
    const [tenantInfo, setTenantInfo] = useState({tenantName: '', tenantId: '', brand: ''});

    const handleClose = () => {
        setOpen(false);
    }

    const handleMenuClick = (type, rowData, closeMenu) => {
        console.log(rowData.original);
        if(type === 'edit') {
        setOpen(true);
        setTenantInfo({...rowData.original});
        closeMenu();
        } else if(type === 'delete') {
            handleDeleteRow(type, rowData.original);
            closeMenu();
        }
    }

    const handleAddTenant = () => {
        setTenantInfo({tenantName: '', tenantId: '', brand: ''});
        setOpen(true);
    }

    const handleChange = event => {
        const value = event.target.value;
        setTenantInfo({
            ...tenantInfo,
            [event.target.name]: value
        });
    };

    const handleAddTenantModal = () => {
        console.log(tenantInfo);
        handleAddRow("add", tenantInfo);
    }
    return (
        <>
            <Dialog open={open} onClose={handleClose} fullWidth={true}>
                <DialogTitle sx={{ backgroundColor: 'rgb(235,10,30)', color: 'rgb(255,255,255)'}}>Add/Edit Tenant</DialogTitle>
                <DialogContent sx={{ paddingRight: 0 }}>
                    <div> <input
                        name="tenantName"
                        className="inpt-label"
                        label="Tenant Name"
                        type="text"
                        placeholder="Tenant Name"
                        size={60}
                        value={tenantInfo.tenantName}
                        onChange={handleChange}
                    /></div>
                    <div> <input
                        name="tenantId"
                        className="inpt-label"
                        label="Tenant Orig ID"
                        type="text"
                        placeholder="Tenant ID"
                        size={60}
                        value={tenantInfo.tenantId}
                        onChange={handleChange}
                    /></div>
                    <div><input
                        name="brand"
                        className="inpt-label"
                        label="Brand"
                        type="text"
                        placeholder="Brand"
                        size={60}
                        value={tenantInfo.brand}
                        onChange={handleChange}
                    /></div>
                </DialogContent>
                <DialogActions>
                    <Button sx={{fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleClose} variant="outlined" size="medium">Cancel</Button>
                    <Button sx={{fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenantModal} variant="outlined" size="medium">Add Tenant</Button>
                </DialogActions>
            </Dialog>
            <div className="add-tnt">
            <Button sx={{fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenant} variant="outlined" size="medium">
                <AddCircleOutlineRoundedIcon />Add Tenant</Button> 
            </div>
            <DataServiceTable columnDefs={columns} tableData={tableData} handleMenuItemClick={handleMenuClick} />
        </>
    )
}

export default TenantTable;