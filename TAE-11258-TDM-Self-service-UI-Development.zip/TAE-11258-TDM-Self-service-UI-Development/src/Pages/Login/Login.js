import React, { useState } from "react";
import './Login.css';
import LoginModel from "../../models/LoginModel";
import { useNavigate } from "react-router-dom";
import loginLogo from './../../assets/images/logo.svg';

const loginModel = new LoginModel();

const Login = () => {
    const [loginInfo, setLoginInfo] = useState({ username: '', password: '' });
    const [btnDisabled, setBtnDisabled] = useState(true);
    const [errorMsg, setErrorMsg] = useState('');
    const navigate = useNavigate();
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("submitted");
        console.log(loginInfo);

        const { username, password } = loginInfo;
        loginModel.login(username, password)
            .then(response => {
                const loginSuccess = response.data.login;
                // navigate('/tenant');
            })
            .catch((error) => {
                console.error(error);
                setErrorMsg("Invalid username/password");
            });
    };

    const handleChange = event => {
        const value = event.target.value;
        setLoginInfo({
            ...loginInfo,
            [event.target.name]: value
        });

        const {username, password} = loginInfo;
        if(username === '' || password === '' || value === '') {
            setBtnDisabled(true);
        }
        else {
            setBtnDisabled(false);
        }
    };

    return (
        <>
            <div className="login-container">
                <div>
                    <img src={loginLogo} width="200" height="50" alt="login page mazda logo" aria-label="login page mazda logo" />
                </div>
                <form action="" onSubmit={handleSubmit}>
                    <div className="logo-div">
                        <img src={loginLogo} width="200" height="50" alt="login page mazda logo" aria-label="login page mazda logo" />
                    </div>
                    <h3>Welcome!</h3>
                    <div>
                        <label htmlFor="username">Username</label>
                        <input className="user-inpt" type="text" name="username" placeholder="Enter username" value={loginInfo.username} onChange={handleChange} id="username" />
                    </div>
                    <div>
                        <label htmlFor="password">Password</label>
                        <input className="user-inpt" type="password" name="password" placeholder="Enter password" value={loginInfo.password} onChange={handleChange} id="password" />
                    </div>
                    {errorMsg && <div className="error-msg">{errorMsg}</div>}
                    <div>
                        <button className={`${btnDisabled ? "btn-disable" : "btn-enable"} login-btn`} disabled={btnDisabled} type="submit">Login</button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default Login;