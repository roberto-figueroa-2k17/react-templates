import React from "react";

const Landing = () => {
    return(
        <>
            <div>Login Page</div>
        </>
    )
}

export default Landing;