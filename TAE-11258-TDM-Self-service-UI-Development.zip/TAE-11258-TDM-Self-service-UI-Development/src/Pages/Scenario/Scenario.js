import React, { useEffect, useState } from "react";
import ScenarioTable from "./ScenarioTable";
import ScenarioModel from "../../models/ScenarioModel";
import './Scenario.css';

const dataModel = new ScenarioModel();

const Scenario = () => {
    const columns = [
        {
            accessorKey: 'scenarioId',
            header: 'S.No',
            size: 50
        },
        {
            accessorKey: 'tenantOrigId',
            header: 'Tenant Name',
            size: 100
        },
        {
            accessorKey: 'viewName',
            header: 'Scenario Name',
            size: 100
        },
    ];
    const sampledata = [
        { scenarioId: 1, tenantOrigId: 'T001', viewName: 'PastDue' },
        { scenarioId: 2, tenantOrigId: 'T002', viewName: 'Bankruptcy' },
        { scenarioId: 3, tenantOrigId: 'T002', viewName: 'SingleAccount' },
        { scenarioId: 4, tenantOrigId: 'T003', viewName: 'MultipleAccount' },
        { scenarioId: 5, tenantOrigId: 'T003', viewName: 'PastDue' },
        { scenarioId: 6, tenantOrigId: 'T003', viewName: 'Bankruptcy' },
        { scenarioId: 7, tenantOrigId: 'T004', viewName: 'SingleAccount' },
        { scenarioId: 8, tenantOrigId: 'T005', viewName: 'MultipleAccount' }
    ];
    const [tableData, setTableData] = useState(sampledata);

    const getScenarioTableData = () => {
        dataModel.getScenarioData()
            .then(resp => setTableData(resp.data))
    }

    const handleDeleteRow = (type, rowData) => {
        console.log(type);
        const tenantId = rowData.tenantId;
        const updatedData = tableData.filter(tenant => tenant.tenantId !== tenantId);
        setTableData(updatedData);
    }
    
    const handleAddRow = (type, rowData) => {
        console.log(type);
    }

    useEffect(() => {
        getScenarioTableData();
    }, []);

    return (
        <>
            <div className="scenario-container">
                <h3 className="scenario-title">Scenario Page</h3>
                <ScenarioTable tableData={tableData} columns={columns} handleDeleteRow={handleDeleteRow} handleAddRow={handleAddRow} />
            </div>
        </>
    )
};

export default Scenario;