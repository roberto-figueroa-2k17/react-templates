import React, { useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  MenuItem,
  Paper,
  Stack,
  TextField,
} from '@mui/material';
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import DataServiceTable from "../../components/DataServiceTable/DataServiceTable";
import { styled } from '@mui/material/styles';
import './ScenarioTable.css';

const ScenarioTable = props => {
  const { tableData, columns, handleDeleteRow, handleAddRow } = props;
  const [open, setOpen] = useState(false);
  const [scenarioInfo, setScenarioInfo] = useState({ scenarioId: '', tenantOrigId: '', viewName: '' });

  const Item = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(0)
  }));

  const handleClose = () => {
    setOpen(false);
  }

  const handleMenuClick = (type, rowData, closeMenu) => {
    console.log(rowData.original);
    if (type === 'edit') {
      setOpen(true);
      setScenarioInfo({ ...rowData.original });
      closeMenu();
    } else if (type === 'delete') {
      handleDeleteRow(type, rowData.original);
      closeMenu();
    }
  }

  const handleAddTenant = () => {
    setScenarioInfo({ scenarioId: '', tenantOrigId: '', viewName: '' });
    setOpen(true);
  }

  const handleChange = event => {
    const value = event.target.value;
    setScenarioInfo({
      ...scenarioInfo,
      [event.target.name]: value
    });
  };

  const handleAddTenantModal = () => {
    console.log(scenarioInfo);
    handleAddRow("add", scenarioInfo);
  }

  return (
    <>
      <Dialog open={open} onClose={handleClose} fullWidth={true}>
        <DialogTitle sx={{ backgroundColor: 'rgb(235,10,30)', color: 'rgb(255,255,255)' }}>Add/Edit Scenario</DialogTitle>
        <DialogContent>
          <Box sx={{ width: '100%', marginTop: '30px' }}>
            <FormControl fullWidth>
            <Stack spacing={3}>
            <Item style={{ border: "0px" }}>
              <TextField
                id="tenantId"
                select
                label="Tenant"
                defaultValue=""
                helperText=""
                fullWidth
              >
                <MenuItem key={1} value={1}>
                  {"Option One"}
                </MenuItem>
                <MenuItem key={2} value={2}>
                  {"Option Two"}
                </MenuItem>
                <MenuItem key={3} value={3}>
                  {"Option Three"}
                </MenuItem>
              </TextField>
            </Item>
            <Item style={{ border: "0px" }}>
              <TextField
                id="viewName"
                select
                label="View Name"
                defaultValue=""
                helperText=""
                fullWidth
              >
                <MenuItem key={1} value={1}>
                  {"Option One"}
                </MenuItem>
                <MenuItem key={2} value={2}>
                  {"Option Two"}
                </MenuItem>
                <MenuItem key={3} value={3}>
                  {"Option Three"}
                </MenuItem>
              </TextField>
            </Item>
            <Item style={{ border: "0px" }}>
              <TextField
                id="tenantId"
                label="Tenant"
                required
                fullWidth
              />
            </Item>
            </Stack>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Box sx={{ width: '100%', marginLeft: '15px', marginRight: '15px', marginBottom: '10px', display: 'flex', justifyContent: 'right' }}>
            <Stack direction="row" spacing={1} style={{ border: "0px" }}>
              <Item>
                <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleClose} variant="outlined" size="medium">Cancel</Button>
              </Item>
              <Item>
                <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenantModal} variant="outlined" size="medium">Add Scenario</Button>
              </Item>
            </Stack>
          </Box>
        </DialogActions>
      </Dialog>
      <div className="add-tnt">
        <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenant} variant="outlined" size="medium">
        <AddCircleOutlineRoundedIcon />Add Scenario</Button>
      </div>
      <DataServiceTable columnDefs={columns} tableData={tableData} handleMenuItemClick={handleMenuClick} />
    </>
  );
}

export default ScenarioTable;