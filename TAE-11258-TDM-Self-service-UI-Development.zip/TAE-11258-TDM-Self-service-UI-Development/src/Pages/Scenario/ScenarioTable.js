import React, { useState } from "react";
import MaterialReactTable from 'material-react-table';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Box from '@mui/material/Box';
import DialogTitle from '@mui/material/DialogTitle';
import { Button, MenuItem } from '@mui/material';
import { EditOutlined, DeleteOutlined } from "@mui/icons-material";
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import './ScenarioTable.css';
import DataServiceTable from "../../components/DataServiceTable/DataServiceTable";

const ScenarioTable = props => {
    const { tableData, columns, handleDeleteRow, handleAddRow } = props;
    const [open, setOpen] = useState(false);
    const [scenarioInfo, setScenarioInfo] = useState({scenarioId: '', tenantOrigId: '', viewName: ''});

    const handleClose = () => {
        setOpen(false);
    }

    const handleMenuClick = (type, rowData, closeMenu) => {
        console.log(rowData.original);
        if(type === 'edit') {
        setOpen(true);
        setScenarioInfo({...rowData.original});
        closeMenu();
        } else if(type === 'delete') {
            handleDeleteRow(type, rowData.original);
            closeMenu();
        }
    }

    const handleAddTenant = () => {
        setScenarioInfo({scenarioId: '', tenantOrigId: '', viewName: ''});
        setOpen(true);
    }

    const handleChange = event => {
        const value = event.target.value;
        setScenarioInfo({
            ...scenarioInfo,
            [event.target.name]: value
        });
    };

    const handleAddTenantModal = () => {
        console.log(scenarioInfo);
        handleAddRow("add", scenarioInfo);
    }
    return (
        <>
            <Dialog open={open} onClose={handleClose} fullWidth={true}>
                <DialogTitle sx={{ backgroundColor: 'rgb(235,10,30)', color: 'rgb(255,255,255)'}}>Add/Edit Scenario</DialogTitle>
                <DialogContent sx={{ paddingRight: 0 }}>
                    <div> <input
                        name="tenantOrigId"
                        className="inpt-label"
                        label="Tenant Name"
                        type="text"
                        placeholder="Tenant Name"
                        size={60}
                        value={scenarioInfo.tenantName}
                        onChange={handleChange}
                    /></div>
                    <div> <input
                        name="viewList"
                        className="inpt-label"
                        label="View List"
                        type="text"
                        placeholder="View List"
                        size={60}
                        value=""
                        onChange={handleChange}
                    /></div>
                    <div><input
                        name="scenarioName"
                        className="inpt-label"
                        label="Scenario Name"
                        type="text"
                        placeholder="Scenario Name"
                        size={60}
                        value={scenarioInfo.viewName}
                        onChange={handleChange}
                    /></div>
                </DialogContent>
                <DialogActions>
                    <Button sx={{fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleClose} variant="outlined" size="medium">Cancel</Button>
                    <Button sx={{fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenantModal} variant="outlined" size="medium">Add Scenario</Button>
                </DialogActions>
            </Dialog>
            <div className="add-tnt">
            <Button sx={{fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenant} variant="outlined" size="medium">
                <AddCircleOutlineRoundedIcon />Add Scenario</Button> 
            </div>
            <DataServiceTable columnDefs={columns} tableData={tableData} handleMenuItemClick={handleMenuClick} />
        </>
    )
}

export default ScenarioTable;