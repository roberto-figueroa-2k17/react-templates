import logo from './logo.svg';
import NavBar from './components/NavBar/NavBar'
import './App.css';
import './components/NavBar/NavBar.css';
import Login  from './Pages/Login/Login';
import Landing  from './Pages/Landing/Landing';
import Scenario from './Pages/Scenario/Scenario';
import Tenant from './Pages/Tenant/Tenant';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <NavBar />
        <Route path="landing" element={<Landing />} />
        <Route path="scenario" element={<Scenario />} />
        <Route path="tenant" element={<Tenant />} />
        {/* </Route> */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
