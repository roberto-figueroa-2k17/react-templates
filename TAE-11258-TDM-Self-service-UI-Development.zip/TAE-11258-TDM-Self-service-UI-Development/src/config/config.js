const config = {};

config.serviceUrl = "";

export default config;