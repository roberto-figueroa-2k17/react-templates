import { scenarioApi } from "../apis/scenario.api"

export default class ScenarioModel {
    addScenarioData = (scenarioId, tenantOrigId, viewName) => {
        return scenarioApi.addScenarioData(scenarioId, tenantOrigId, viewName);
    }

    getScenarioData = () => {
        return scenarioApi.getScenarioData();
    }

    deleteScenarioData = (scenarioId, tenantOrigId, viewName) => {
        return scenarioApi.addScenarioData(scenarioId, tenantOrigId, viewName);
    }
}