const config = {};

/** 
 * API base URL
 */
config.serviceUrl = "http://localhost:8080/data-reservation-services/v1/mfs";

export default config;