import React, { useEffect, useState } from "react";
import ScenarioTable from "./ScenarioTable";
import ScenarioModel from "../../models/ScenarioModel";
import './Scenario.css';

const dataModel = new ScenarioModel();

const Scenario = () => {
    const columns = [
        {
            accessorKey: 'scenarioId',
            header: 'S.No',
            size: 50
        },
        {
            accessorKey: 'tenantName',
            header: 'Tenant Name',
            size: 100
        },
        {
            accessorKey: 'viewName',
            header: 'Scenario Name',
            size: 100
        },
    ];

    const initData = [
        { scenarioId: null, tenantName: null, viewName: null}
    ];

    const [tableData, setTableData] = useState(false);

    const getScenarioTableData = () => {
        dataModel.getScenarioData()
            .then(resp => setTableData(resp.data))
    }

    const handleDeleteRow = (type, rowData) => {
        console.log(type);
        const scenarioId = rowData.scenarioId;
        const updatedData = tableData.filter(scenario => scenario.scenarioId !== scenarioId);
        setTableData(updatedData);
    }

    const handleAddRow = (type, rowData) => {
        console.log(type);
    }

    useEffect(() => {
        getScenarioTableData();
    }, []);

    return (
        <>
            <div>
                {/* <TDMAppBar /> */}
                <div className="scenario-container">
                    <h3 className="scenario-title">Scenario Page</h3>
                    <ScenarioTable tableData={tableData} columns={columns} handleDeleteRow={handleDeleteRow} handleAddRow={handleAddRow}/>
                </div>
            </div>
        </>
    )
};

export default Scenario;