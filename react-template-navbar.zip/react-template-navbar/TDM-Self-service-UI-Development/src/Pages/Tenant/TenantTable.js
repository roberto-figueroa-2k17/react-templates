import React, { useState } from "react";
import TextField from '@mui/material/TextField';
import { Backdrop, CircularProgress, Dialog, Modal } from '@mui/material';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Box from '@mui/material/Box';
import DialogTitle from '@mui/material/DialogTitle';
import { Button } from '@mui/material';
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import './TenantTable.css';
import DataServiceTable from "../../components/DataServiceTable/DataServiceTable";


const TenantTable = props => {
    const { tableData, columns, handleDeleteRow, handleAddRow } = props;
    const [open, setOpen] = useState(false);
    const [openDeleteModal, setOpenDeleteModal] = useState(false);
    const [tenantInfo, setTenantInfo] = useState({ tenantName: '', tenantId: '', brand: '' });
    const [currentRecord, setCurrentRecord] = useState({ tenantName: '', tenantId: '', brand: '' });
    const [loading, setLoading] = useState(false);

    const handleClose = () => {
        setOpen(false);
    }

    const closeDeleteModal = () => {
        setOpenDeleteModal(false);
    }

    const handleMenuClick = (type, rowData, closeMenu) => {
        console.log(rowData.original);
        if (type === 'edit') {
            setOpen(true);
            setTenantInfo({ ...rowData.original });
            closeMenu();
        } else if (type === 'delete') {
            setOpenDeleteModal(true);
            setCurrentRecord(rowData.original);
            closeMenu();
        }
    }

    const handleDeleteTenant = () => {
        handleDeleteRow("delete", currentRecord);
        closeDeleteModal();
    }

    const handleAddTenant = () => {
        setTenantInfo({ tenantName: '', tenantId: '', brand: '' });
        setOpen(true);
    }

    const handleChange = event => {
        const value = event.target.value;
        setTenantInfo({
            ...tenantInfo,
            [event.target.name]: value
        });
    };

    const handleAddTenantModal = () => {
        console.log(tenantInfo);
        setLoading(true);
        handleAddRow("add", tenantInfo);
        handleClose();
        setLoading(false);
    }
    return (
        <>
            <div>
                <Backdrop
                    sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={loading}
                    onClick={handleClose}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            </div>
            <Dialog id="add-tenant" open={open} onClose={handleClose} fullWidth={true}>
                <DialogTitle sx={{ backgroundColor: 'rgb(235,10,30)', color: 'rgb(255,255,255)' }}>Add/Edit Tenant</DialogTitle>
                <DialogContent sx={{ paddingRight: 0 }}>
                    <div> <input
                        name="tenantName"
                        className="inpt-label"
                        label="Tenant Name"
                        type="text"
                        placeholder="Tenant Name"
                        size={60}
                        value={tenantInfo.tenantName}
                        onChange={handleChange}
                    /></div>
                    <div> <input
                        name="tenantId"
                        className="inpt-label"
                        label="Tenant Orig ID"
                        type="text"
                        placeholder="Tenant ID"
                        size={60}
                        value={tenantInfo.tenantId}
                        onChange={handleChange}
                    /></div>
                    <div><input
                        name="brand"
                        className="inpt-label"
                        label="Brand"
                        type="text"
                        placeholder="Brand"
                        size={60}
                        value={tenantInfo.brand}
                        onChange={handleChange}
                    /></div>
                </DialogContent>
                <DialogActions>
                    <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleClose} variant="outlined" size="medium">Cancel</Button>
                    <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenantModal} variant="outlined" size="medium">Add Tenant</Button>
                </DialogActions>
            </Dialog>
            <Dialog id="delete-tenant" open={openDeleteModal} onClose={closeDeleteModal} fullWidth={true}>
                <DialogTitle sx={{ backgroundColor: 'rgb(235,10,30)', color: 'rgb(255,255,255)' }}>Are you sure you want to delete?</DialogTitle>

                <DialogActions>
                    <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={closeDeleteModal} variant="outlined" size="medium">No</Button>
                    <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleDeleteTenant} variant="outlined" size="medium">Yes</Button>
                </DialogActions>
            </Dialog>
            <div className="add-tnt">
                <Button sx={{ fontWeight: 400, backgroundColor: 'rgb(235,10,30)', color: 'rgba(255,255,255)' }} onClick={handleAddTenant} variant="outlined" size="medium">
                    <AddCircleOutlineRoundedIcon />Add Tenant</Button>
            </div>
            <DataServiceTable columnDefs={columns} tableData={tableData} handleMenuItemClick={handleMenuClick} />
        </>
    )
}

export default TenantTable;