import React, { useEffect, useState } from "react";
import TenantTable from "./TenantTable";
import TenantModel from "../../models/TenantModel";
import './Tenant.css';
import TDMAppBar from "../../components/TdmAppBar/TDMAppBar";

const dataModel = new TenantModel();

const Tenant = () => {
    const columns = [
        {
            accessorKey: 'no',
            header: 'S.NO',
            size: 50
        },
        {
            accessorKey: 'tenantName',
            header: 'Tenant Name',
            size: 100
        },
        {
            accessorKey: 'tenantId',
            header: 'Tenant ID',
            size: 100
        },
        {
            accessorKey: 'brand',
            header: 'Brand',
            size: 50
        },
    ];
    const sampledata = [
        { no: 1, tenantName: 'Toyota Financial Services', tenantId: 'T001', brand: 'T' },
        { no: 2, tenantName: 'Lexus Financial Services', tenantId: 'T003', brand: 'L' },
        { no: 3, tenantName: 'Mazda Financial Services', tenantId: 'T007', brand: 'M' },
        { no: 4, tenantName: 'Basspro Financial Services', tenantId: 'T004', brand: 'B' },
        { no: 5, tenantName: 'Toyota1 Financial Services', tenantId: 'T006', brand: 'T' },
        { no: 6, tenantName: 'Lexus2 Financial Services', tenantId: 'T002', brand: 'L' },
        { no: 7, tenantName: 'Mazda3 Financial Services', tenantId: 'T009', brand: 'M' },
        { no: 8, tenantName: 'Basspro4 Financial Services', tenantId: 'T005', brand: 'B' }
    ];
    const [tableData, setTableData] = useState(sampledata);

    const getTenantTableData = () => {
        dataModel.getTenantData()
            .then(resp => setTableData(resp.data))
    }

    const handleDeleteRow = (type, rowData) => {
        console.log(type);
        const tenantId = rowData.tenantId;
        const updatedData = tableData.filter(tenant => tenant.tenantId !== tenantId);
        setTableData(updatedData);
    }
    
    const handleAddRow = (type, rowData) => {
        console.log(type);
    }

    useEffect(() => {
        getTenantTableData();
    }, []);

    return (
        <>
            <div>
                {/* <TDMAppBar /> */}
                <div className="tenant-container">
                    <h3 className="tenant-title">Tenant Page</h3>
                    <TenantTable tableData={tableData} columns={columns} handleDeleteRow={handleDeleteRow} handleAddRow={handleAddRow}/>
                </div>
            </div>
        </>
    )
};

export default Tenant;