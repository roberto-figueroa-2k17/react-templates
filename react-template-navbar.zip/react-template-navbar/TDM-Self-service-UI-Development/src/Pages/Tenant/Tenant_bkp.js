import React, { useEffect, useState } from "react";
import TenantTable from "./TenantTable";
import TenantModel from "../../models/TenantModel";
import './Tenant.css';
import TDMAppBar from "../../components/TdmAppBar/TDMAppBar"; 

export class Tenant extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            columns: [
                {
                    accessorKey: 'no',
                    header: 'S.NO',
                    size: 50
                },
                {
                    accessorKey: 'tenantName',
                    header: 'Tenant Name',
                    size: 100
                },
                {
                    accessorKey: 'tenantId',
                    header: 'Tenant ID',
                    size: 100
                },
                {
                    accessorKey: 'brand',
                    header: 'Brand',
                    size: 50
                },
            ],
            tableData: [
                { no: 1, tenantName: 'Toyota Financial Services', tenantId: 'T001', brand: 'T' },
                { no: 2, tenantName: 'Lexus Financial Services', tenantId: 'T003', brand: 'L' },
                { no: 3, tenantName: 'Mazda Financial Services', tenantId: 'T007', brand: 'M' },
                { no: 4, tenantName: 'Basspro Financial Services', tenantId: 'T004', brand: 'B' },
                { no: 5, tenantName: 'Toyota1 Financial Services', tenantId: 'T006', brand: 'T' },
                { no: 6, tenantName: 'Lexus2 Financial Services', tenantId: 'T002', brand: 'L' },
                { no: 7, tenantName: 'Mazda3 Financial Services', tenantId: 'T009', brand: 'M' },
                { no: 8, tenantName: 'Basspro4 Financial Services', tenantId: 'T005', brand: 'B' }
            ]
        }
        this.dataModel = new TenantModel();
    }

    componentDidMount() {
        this.getTenantTableData();
    }
    // const [tableData, setTableData] = useState(sampledata);

     getTenantTableData = () => {
        this.dataModel.getTenantData()
            .then(resp => this.setState({tableData: resp.data}))
    }

     handleDeleteRow = (type, rowData) => {
        const { tableData } = this.state;
        console.log(type);
        const tenantId = rowData.tenantId;
        const updatedData = tableData.filter(tenant => tenant.tenantId !== tenantId);
        this.setState({tableData: updatedData});
    }
    
     handleAddRow = (type, rowData) => {
        console.log(type);
    }

    // useEffect(() => {
    //     getTenantTableData();
    // }, []);
    render() {
        const {tableData, columns} = this.state;
    return (
        <>
            <div>
                {/* <TDMAppBar /> */}
                <div className="tenant-container">
                    <h3 className="tenant-title">Tenant Page</h3>
                    <TenantTable tableData={tableData} columns={columns} handleDeleteRow={this.handleDeleteRow} handleAddRow={this.handleAddRow}/>
                </div>
            </div>
        </>
    )
    }
};

export default Tenant;