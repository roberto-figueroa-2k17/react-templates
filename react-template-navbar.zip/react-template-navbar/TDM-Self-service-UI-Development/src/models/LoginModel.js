import { loginApi } from "../apis/login.api";

export default class LoginModel {

    login = (username, password) => {
        return loginApi.login(username, password);
    }
}
