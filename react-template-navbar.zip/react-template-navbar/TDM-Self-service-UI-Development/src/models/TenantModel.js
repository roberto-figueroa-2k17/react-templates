import { tenantApi } from "../apis/tenant.api"

export default class TenantModel {
    addTenantData = (tenantName, tenantId, brand ) => {
        return tenantApi.addTenantData(tenantName,tenantId,brand);
    }

    getTenantData = () => {
        return tenantApi.getTenantData();
    }

    deleteTenantData = (tenantName, tenantId, brand) => {
        return tenantApi.deleteTenantData(tenantName, tenantId, brand);
    }
}