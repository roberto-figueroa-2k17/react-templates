import { scenarioApi } from "../apis/scenario.api"

export default class ScenarioModel {
    addScenarioData = (scenarioId, tenantId, viewName) => {
        return scenarioApi.addScenarioData(scenarioId, tenantId, viewName);
    }

    getScenarioData = (tenantId, brandId) => {
        return scenarioApi.getScenarioData(tenantId, brandId);
    }

    getTenantData = (tenantId, brandId) => {
        return scenarioApi.getTenantData(tenantId, brandId);
    }

    deleteScenarioData = (scenarioId, tenantId, viewName) => {
        return scenarioApi.addScenarioData(scenarioId, tenantId, viewName);
    }
}