import React, { useState } from "react";
import MaterialReactTable from 'material-react-table';
import { MenuItem, withStyles } from '@mui/material';
import { EditOutlined, DeleteOutlined } from "@mui/icons-material";

const DataServiceTable = props => {
    const { columnDefs = [], tableData = [], handleMenuItemClick = () => { } } = props;
    return (
        <>
            <MaterialReactTable
                columns={columnDefs}
                data={tableData}
                enableTopToolbar={false}
                positionActionsColumn="last"
                enableRowActions
                renderRowActionMenuItems={({ row, table, closeMenu }) => [
                    <MenuItem key="edit" onClick={() => handleMenuItemClick("edit", row, closeMenu)}>
                        <EditOutlined />Edit
                    </MenuItem>,
                    <MenuItem key="delete" onClick={() => handleMenuItemClick("delete", row, closeMenu)}>
                        <DeleteOutlined /> Delete
                    </MenuItem>,
                ]}
                muiTableHeadCellProps={{
                    sx: (theme) => ({
                        background: 'rgb(235,10,30)',
                        borderRight: '1px solid rgba(224,224,224,1)',
                        color: 'rgb(255,255,255)',
                    }),
                }}
                muiTableBodyProps={{
                    hover: "false",
                    sx: () => ({
                        '& tr:nth-of-type(odd)': {
                            backgroundColor: '#f9e9ea',
                        },
                    }),
                }}
            />
        </>
    )
};

export default DataServiceTable;