import axios from 'axios';
import config from '../config/config';

const addScenarioData = (scenarioId, tenantId, viewName) => {
    return axios.post(config.serviceUrl + '/addScenarioData', {scenarioId, tenantId, viewName});
}

const getScenarioData = (tenantId, brandId) => {
    return axios.get(config.serviceUrl + '/scenario_management/scenarios', {headers: {tenantId : 'T002', brandId : 'M'}});
}

const getTenantData = (tenantId, brandId) => {
    return axios.get(config.serviceUrl + '/scenario_management//tenant_name', {headers: {tenantId : 'T002', brandId : 'M'}});
}

const deleteScenarioData = (scenarioId, tenantId, viewName) => {
    return axios.post(config.serviceUrl + '/deleteScenarioData', {scenarioId, tenantId, viewName});
}

export const scenarioApi = {
    addScenarioData, 
    getScenarioData, 
    getTenantData,
    deleteScenarioData
}