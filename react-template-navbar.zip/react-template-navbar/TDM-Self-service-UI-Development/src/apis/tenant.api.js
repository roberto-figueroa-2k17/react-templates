import axios from 'axios';
import config from '../config/config';

const addTenantData = (tenantName, tenantId, brand) => {
    return axios.post(config.serviceUrl + '/sys_auth/addTenantData', {tenantName, tenantId, brand});
}

const getTenantData = () => {
    return axios.get(config.serviceUrl + '/sys_auth/getTenantData');
}

const deleteTenantData = (tenantName, tenantId, brand) => {
    return axios.post(config.serviceUrl + '/sys_auth/deleteTenantData', {tenantName, tenantId, brand});
}

export const tenantApi = {
    getTenantData,
    addTenantData,
    deleteTenantData
};