import axios from 'axios';
import config from '../config/config';

const login = (username, password) => {
    const userPassword = password;
    /* return await fetch(config.serviceUrl + '/login', {mode: 'cors'}) */
    return axios.get(config.serviceUrl + '/login', {headers: {username, userPassword}});
}

export const loginApi = {
    login
};