import logo from './logo.svg';
import './App.css';
import Login  from './Pages/Login/Login';
import Landing  from './Pages/Landing/Landing';
import Scenario from './Pages/Scenario/Scenario';
import Tenant from './Pages/Tenant/Tenant';
import NavBarLayout from './layouts/NavBarLayout';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/login" element={<Login />} />
                <Route element={<NavBarLayout />}>
                    <Route path="landing" element={<Landing />} />
                    <Route path="scenario" element={<Scenario />} />
                    <Route path="tenant" element={<Tenant />} />
                    {/* </Route> */}
                </Route>
            </Routes>
        </BrowserRouter>
    )
}

export default App;
