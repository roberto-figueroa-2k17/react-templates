export default function Tenant() {
  return <h1>Tenant</h1>
}
