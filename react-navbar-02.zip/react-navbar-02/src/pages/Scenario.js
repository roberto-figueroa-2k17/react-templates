export default function Scenario() {
  return <h1>Scenario</h1>
}
