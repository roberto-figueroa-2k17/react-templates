export default function DataReservation() {
  return <h1>Data Reservation</h1>
}
