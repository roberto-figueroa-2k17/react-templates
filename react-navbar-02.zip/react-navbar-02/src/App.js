import Navbar from "./Navbar"
import Home from "./pages/Home"
import DataReservation from "./pages/DataReservation"
import Scenario from "./pages/Scenario"
import Tenant from "./pages/Tenant"
import { Route, Routes } from "react-router-dom"

function App() {
  return (
    <>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/data-reservation" element={<DataReservation />} />
          <Route path="/tenant" element={<Tenant />} />
          <Route path="/scenario" element={<Scenario />} />
        </Routes>
      </div>
    </>
  )
}

export default App
